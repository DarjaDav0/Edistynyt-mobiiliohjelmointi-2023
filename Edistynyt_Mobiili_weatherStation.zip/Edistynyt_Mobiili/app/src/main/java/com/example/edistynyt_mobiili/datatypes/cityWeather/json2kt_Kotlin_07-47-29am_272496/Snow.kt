package com.example.edistynyt_mobiili

import com.google.gson.annotations.SerializedName


data class Snow (

  @SerializedName("1h" ) var h : Double? = null

)