package com.example.edistynyt_mobiili

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.edistynyt_mobiili.databinding.FragmentFeedbackSendBinding
import com.example.edistynyt_mobiili.databinding.FragmentTempAccessBinding
import org.json.JSONObject
import java.io.UnsupportedEncodingException


class TempAccessFragment : Fragment() {

    private var _binding: FragmentTempAccessBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentTempAccessBinding.inflate(inflater, container, false)
        val root: View = binding.root



        return root
    }

    // VARIABLES USED BY THE SESSION MANAGEMENT
    val LOGIN_URL = "PALVELUN LOGIN URL TÄHÄN"

    // these should be placed in the local properties file and used by BuildConfig
    // JSON_URL should be WITHOUT a trailing slash (/)!
    val JSON_URL = "API URL / SERVICE ID"

    // only if the services uses this (e.g. IBM Cloud), otherwise, not needed
    val apikey = "YOUR API KEY"

    // if using username + password in the service (e.g. Directus), use these
    val username = "darja.davydova.dd@gmail.com"
    val password = "USER PASSWORD IN DIRECTUS"

    // request queues for requests
    var requestQueue: RequestQueue? = null
    var refreshRequestQueue: RequestQueue? = null

    // state booleans to determine our session state
    var loggedIn: Boolean = false
    var needsRefresh: Boolean = false

    // stored tokens. refresh is used when our session token has expired
    // access token in this case is the same as session token
    var refreshToken = ""
    var accessToken = ""

    // fragment entry point
    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        super.onViewCreated(view, savedInstanceState);

        requestQueue = Volley.newRequestQueue(context)
        refreshRequestQueue = Volley.newRequestQueue(context)

        // start with login
        loginAction()
    }

    // button methods
    fun loginAction()
    {
        Log.d("ADVTECH", "login")
        Log.d("ADVTECH", JSON_URL + " login")
        requestQueue?.add(loginRequest)
    }

    fun refreshLogin() {
        if (needsRefresh) {
            loggedIn = false
            // use this if using refresh logic
            //refreshRequestQueue?.add(loginRefreshRequest)

            // if using refresh logic, comment this line out
            loginAction()
        }
    }

    fun dataAction() {
        if (loggedIn) {
            requestQueue?.add(dataRequest)
        }
    }

    // REQUEST OBJECTS

    // REQUEST OBJECT 1: LOGIN
    var loginRequest: StringRequest = object : StringRequest(
        Request.Method.POST, LOGIN_URL,
        Response.Listener { response ->

            var responseJSON: JSONObject = JSONObject(response)

            // save the refresh token too if using refresh logic
            // refreshToken = responseJSON.get("refresh_token").toString()

            // this part depends completely on the service that is used
            // Directus uses the data -> access_token -approach
            // IBM Cloud handles the version in comments
            // accessToken = responseJSON.get("access_token").toString()
            accessToken = responseJSON.getJSONObject("data").get("access_token").toString()

            loggedIn = true

            // after login's done, get data from API
            dataAction()

            Log.d("ADVTECH", response)
        },
        Response.ErrorListener {
            // typically this is a connection error
            Log.d("ADVTECH", it.toString())
        }) {
        @Throws(AuthFailureError::class)
        override fun getHeaders(): Map<String, String> {
            // we have to provide the basic header info
            // + Bearer info => accessToken
            val headers = HashMap<String, String>()
            headers["Accept"] = "application/json"

            // IBM Cloud expects the Content-Type to be the following:
            // headers["Content-Type"] = "application/x-www-form-urlencoded"

            // for Directus, the typical approach works:
            headers["Content-Type"] = "application/json; charset=utf-8"

            return headers
        }

        // uncomment these methods if using IBM Cloud
        /*
        override fun getBodyContentType(): String? {
            return "application/x-www-form-urlencoded; charset=UTF-8"
        }


        @Throws(AuthFailureError::class)
        override fun getParams(): Map<String, String>? {
            val params: MutableMap<String, String> = HashMap()


            params["grant_type"] = "urn:ibm:params:oauth:grant-type:apikey"
            params["apikey"] = apikey
            return params
        }
        */

        // use this to build the needed JSON-object
        // this approach is used by Directus, IBM Cloud uses the commented version instead
        @Throws(AuthFailureError::class)
        override fun getBody(): ByteArray {
            // this function is only needed when sending data
            var body = ByteArray(0)
            try {
                // on how to create this newData -variable
                var newData = ""

                // a very quick 'n dirty approach to creating the needed JSON body for login
                newData = "{\"email\":\"${username}\", \"password\": \"${password}\"}"

                // JSON to bytes
                body = newData.toByteArray(Charsets.UTF_8)
            } catch (e: UnsupportedEncodingException) {
                // problems with converting our data into UTF-8 bytes
            }
            return body
        }

    }

    /*
    // REQUEST OBJECT 2: REFRESH - Not needed by IBM Cloudant by default
    // use this if you're using refresh logic
    var loginRefreshRequest: StringRequest = object : StringRequest(
            Request.Method.POST, LOGIN_URL,
            Response.Listener { response ->

                Log.d("ADVTECH", "REFRESH: " + response)

                var responseJSON: JSONObject = JSONObject(response)
                accessToken = responseJSON.get("access_token").toString()

                loggedIn = true
                needsRefresh = false

                dataAction()
            },
            Response.ErrorListener {
                // typically this is a connection error
                Log.d("ADVTECH", it.toString())
            }) {
        @Throws(AuthFailureError::class)
        override fun getHeaders(): Map<String, String> {
            // we have to provide the basic header info
            // + Bearer info => accessToken
            val headers = HashMap<String, String>()
            headers["Accept"] = "application/json"
            headers["Content-Type"] = "application/json; charset=utf-8"
            headers["Authorization"] = "Bearer " + refreshToken
            return headers
        }

    }
    */

    // REQUEST OBJECT 3 : ACTUAL DATA -> FEEDBACK
    var dataRequest: StringRequest = object : StringRequest(
        Request.Method.GET, JSON_URL+"polku feedback-dataan, riippuu palvelusta",
        Response.Listener { response ->
            Log.d("ADVTECH", response);
        },
        Response.ErrorListener {
            // typically this is a connection error
            Log.d("ADVTECH", it.toString())

            if (it is AuthFailureError) {
                Log.d("ADVTECH", "EXPIRED start")

                needsRefresh = true
                loggedIn = false
                refreshLogin()

                Log.d("ADVTECH", "EXPIRED end")
            }
        }) {
        @Throws(AuthFailureError::class)
        override fun getHeaders(): Map<String, String> {
            // we have to provide the basic header info
            // + Bearer info => accessToken
            val headers = HashMap<String, String>()
            // headers["Accept"] = "application/json"
            // headers["Content-Type"] = "application/json; charset=utf-8"
            headers["Authorization"] = "Bearer " + accessToken
            return headers
        }

    }

}