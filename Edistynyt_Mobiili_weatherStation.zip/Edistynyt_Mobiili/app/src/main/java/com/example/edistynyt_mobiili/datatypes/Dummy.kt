package com.example.edistynyt_mobiili.datatypes

class Dummy {
}