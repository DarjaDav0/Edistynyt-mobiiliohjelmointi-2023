package com.example.edistynyt_mobiili

import androidx.fragment.app.Fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.example.edistynyt_mobiili.databinding.FragmentMapsBinding

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

class MapsFragment : Fragment(), GoogleMap.OnMarkerClickListener {

    // change this to match your fragment name
    private var _binding: FragmentMapsBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private val callback = OnMapReadyCallback { googleMap ->

        gMap = googleMap
        googleMap.setOnMarkerClickListener(this)

        val sydney = LatLng(-34.0, 151.0)
        val marker1: Marker? = googleMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        googleMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))

        val rovaniemi = LatLng(66.5032993751834, 25.732518070836417)
        val marker2: Marker? = googleMap.addMarker(MarkerOptions().position(rovaniemi).title("Marker in Rovaniemi"))
        googleMap.addMarker(MarkerOptions().position(rovaniemi).title("Marker in Rovaniemi"))
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(rovaniemi))

        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(rovaniemi, 15f))

    }

    private lateinit var gMap: GoogleMap

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMapsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        binding.ZoomControlCheckBox.setOnCheckedChangeListener { compoundButton, b ->
            gMap.uiSettings.isZoomControlsEnabled = b
        }

        binding.radioButtonNormalMap.setOnCheckedChangeListener { compoundButton, b ->
            if (compoundButton.isChecked) {
                gMap.mapType = GoogleMap.MAP_TYPE_NORMAL
            }
        }

        binding.radioButtonHybridMap.setOnCheckedChangeListener { compoundButton, b ->
            if (compoundButton.isChecked) {
                gMap.mapType = GoogleMap.MAP_TYPE_HYBRID
            }
        }

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)
    }

    override fun onMarkerClick(p0: Marker): Boolean {
        Log.d("ADVTECH", "MARKKERI")

        Log.d("ADVTECH", p0.position.latitude.toString())
        Log.d("ADVTECH", p0.position.longitude.toString())
        Log.d("ADVTECH", p0.tag.toString())
        //navigoidaam cityweather fragmentiin ja laitetaan koordinaatit argumenteina
        val action = MapsFragmentDirections.actionMapsFragmentToCityWeatherFragment(p0.position.latitude.toFloat(), p0.position.longitude.toFloat())
        this.findNavController().navigate(action)
        return false
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}