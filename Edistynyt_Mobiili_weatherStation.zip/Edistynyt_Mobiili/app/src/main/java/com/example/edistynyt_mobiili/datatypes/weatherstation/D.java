
package com.example.edistynyt_mobiili.datatypes.weatherstation;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class D {

    @SerializedName("1")
    @Expose
    private com.example.edistynyt_mobiili.datatypes.weatherstation._1 _1;
    @SerializedName("2")
    @Expose
    private com.example.edistynyt_mobiili.datatypes.weatherstation._2 _2;
    @SerializedName("3")
    @Expose
    private com.example.edistynyt_mobiili.datatypes.weatherstation._3 _3;
    @SerializedName("4")
    @Expose
    private com.example.edistynyt_mobiili.datatypes.weatherstation._4 _4;
    @SerializedName("6")
    @Expose
    private com.example.edistynyt_mobiili.datatypes.weatherstation._6 _6;
    @SerializedName("7")
    @Expose
    private com.example.edistynyt_mobiili.datatypes.weatherstation._7 _7;
    @SerializedName("8")
    @Expose
    private com.example.edistynyt_mobiili.datatypes.weatherstation._8 _8;
    @SerializedName("9")
    @Expose
    private com.example.edistynyt_mobiili.datatypes.weatherstation._9 _9;
    @SerializedName("10")
    @Expose
    private com.example.edistynyt_mobiili.datatypes.weatherstation._10 _10;
    @SerializedName("11")
    @Expose
    private com.example.edistynyt_mobiili.datatypes.weatherstation._11 _11;

    /**
     * No args constructor for use in serialization
     * 
     */
    public D() {
    }

    /**
     * 
     * @param _1
     * @param _2
     * @param _3
     * @param _4
     * @param _6
     * @param _7
     * @param _8
     * @param _9
     * @param _11
     * @param _10
     */
    public D(com.example.edistynyt_mobiili.datatypes.weatherstation._1 _1, com.example.edistynyt_mobiili.datatypes.weatherstation._2 _2, com.example.edistynyt_mobiili.datatypes.weatherstation._3 _3, com.example.edistynyt_mobiili.datatypes.weatherstation._4 _4, com.example.edistynyt_mobiili.datatypes.weatherstation._6 _6, com.example.edistynyt_mobiili.datatypes.weatherstation._7 _7, com.example.edistynyt_mobiili.datatypes.weatherstation._8 _8, com.example.edistynyt_mobiili.datatypes.weatherstation._9 _9, com.example.edistynyt_mobiili.datatypes.weatherstation._10 _10, com.example.edistynyt_mobiili.datatypes.weatherstation._11 _11) {
        super();
        this._1 = _1;
        this._2 = _2;
        this._3 = _3;
        this._4 = _4;
        this._6 = _6;
        this._7 = _7;
        this._8 = _8;
        this._9 = _9;
        this._10 = _10;
        this._11 = _11;
    }

    public com.example.edistynyt_mobiili.datatypes.weatherstation._1 get1() {
        return _1;
    }

    public void set1(com.example.edistynyt_mobiili.datatypes.weatherstation._1 _1) {
        this._1 = _1;
    }

    public D with1(com.example.edistynyt_mobiili.datatypes.weatherstation._1 _1) {
        this._1 = _1;
        return this;
    }

    public com.example.edistynyt_mobiili.datatypes.weatherstation._2 get2() {
        return _2;
    }

    public void set2(com.example.edistynyt_mobiili.datatypes.weatherstation._2 _2) {
        this._2 = _2;
    }

    public D with2(com.example.edistynyt_mobiili.datatypes.weatherstation._2 _2) {
        this._2 = _2;
        return this;
    }

    public com.example.edistynyt_mobiili.datatypes.weatherstation._3 get3() {
        return _3;
    }

    public void set3(com.example.edistynyt_mobiili.datatypes.weatherstation._3 _3) {
        this._3 = _3;
    }

    public D with3(com.example.edistynyt_mobiili.datatypes.weatherstation._3 _3) {
        this._3 = _3;
        return this;
    }

    public com.example.edistynyt_mobiili.datatypes.weatherstation._4 get4() {
        return _4;
    }

    public void set4(com.example.edistynyt_mobiili.datatypes.weatherstation._4 _4) {
        this._4 = _4;
    }

    public D with4(com.example.edistynyt_mobiili.datatypes.weatherstation._4 _4) {
        this._4 = _4;
        return this;
    }

    public com.example.edistynyt_mobiili.datatypes.weatherstation._6 get6() {
        return _6;
    }

    public void set6(com.example.edistynyt_mobiili.datatypes.weatherstation._6 _6) {
        this._6 = _6;
    }

    public D with6(com.example.edistynyt_mobiili.datatypes.weatherstation._6 _6) {
        this._6 = _6;
        return this;
    }

    public com.example.edistynyt_mobiili.datatypes.weatherstation._7 get7() {
        return _7;
    }

    public void set7(com.example.edistynyt_mobiili.datatypes.weatherstation._7 _7) {
        this._7 = _7;
    }

    public D with7(com.example.edistynyt_mobiili.datatypes.weatherstation._7 _7) {
        this._7 = _7;
        return this;
    }

    public com.example.edistynyt_mobiili.datatypes.weatherstation._8 get8() {
        return _8;
    }

    public void set8(com.example.edistynyt_mobiili.datatypes.weatherstation._8 _8) {
        this._8 = _8;
    }

    public D with8(com.example.edistynyt_mobiili.datatypes.weatherstation._8 _8) {
        this._8 = _8;
        return this;
    }

    public com.example.edistynyt_mobiili.datatypes.weatherstation._9 get9() {
        return _9;
    }

    public void set9(com.example.edistynyt_mobiili.datatypes.weatherstation._9 _9) {
        this._9 = _9;
    }

    public D with9(com.example.edistynyt_mobiili.datatypes.weatherstation._9 _9) {
        this._9 = _9;
        return this;
    }

    public com.example.edistynyt_mobiili.datatypes.weatherstation._10 get10() {
        return _10;
    }

    public void set10(com.example.edistynyt_mobiili.datatypes.weatherstation._10 _10) {
        this._10 = _10;
    }

    public D with10(com.example.edistynyt_mobiili.datatypes.weatherstation._10 _10) {
        this._10 = _10;
        return this;
    }

    public com.example.edistynyt_mobiili.datatypes.weatherstation._11 get11() {
        return _11;
    }

    public void set11(com.example.edistynyt_mobiili.datatypes.weatherstation._11 _11) {
        this._11 = _11;
    }

    public D with11(com.example.edistynyt_mobiili.datatypes.weatherstation._11 _11) {
        this._11 = _11;
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(D.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("_1");
        sb.append('=');
        sb.append(((this._1 == null)?"<null>":this._1));
        sb.append(',');
        sb.append("_2");
        sb.append('=');
        sb.append(((this._2 == null)?"<null>":this._2));
        sb.append(',');
        sb.append("_3");
        sb.append('=');
        sb.append(((this._3 == null)?"<null>":this._3));
        sb.append(',');
        sb.append("_4");
        sb.append('=');
        sb.append(((this._4 == null)?"<null>":this._4));
        sb.append(',');
        sb.append("_6");
        sb.append('=');
        sb.append(((this._6 == null)?"<null>":this._6));
        sb.append(',');
        sb.append("_7");
        sb.append('=');
        sb.append(((this._7 == null)?"<null>":this._7));
        sb.append(',');
        sb.append("_8");
        sb.append('=');
        sb.append(((this._8 == null)?"<null>":this._8));
        sb.append(',');
        sb.append("_9");
        sb.append('=');
        sb.append(((this._9 == null)?"<null>":this._9));
        sb.append(',');
        sb.append("_10");
        sb.append('=');
        sb.append(((this._10 == null)?"<null>":this._10));
        sb.append(',');
        sb.append("_11");
        sb.append('=');
        sb.append(((this._11 == null)?"<null>":this._11));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
