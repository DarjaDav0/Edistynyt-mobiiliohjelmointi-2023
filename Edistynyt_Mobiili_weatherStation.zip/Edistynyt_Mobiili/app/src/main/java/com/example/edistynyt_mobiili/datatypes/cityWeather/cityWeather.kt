package com.example.edistynyt_mobiili.datatypes.cityWeather

class cityWeather {

}