package com.example.edistynyt_mobiili

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.navArgs
import com.example.edistynyt_mobiili.databinding.FragmentApiDetailBinding

// ApiDetailFragmentissa voidaan ottaa muuttuja vastaan

class ApiDetailFragment : Fragment() {
    private var _binding: FragmentApiDetailBinding? = null

    // get fragment parameters from previous fragment
    val args: DetailFragmentArgs by navArgs()

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentApiDetailBinding.inflate(inflater, container, false)
        val root: View = binding.root
        // print out the given parameter into logs

        Log.d("ADVTECH", "ID = " + args.id.toString())

        val JSON_URL = "https://jsonplaceholder.typicode.com/comments/" + args.id.toString()
        Log.d("ADVTECH", JSON_URL)

        // Tästä eteenpäin datan voi hakea kolmella tavalla:

        // 1. Käydä id:tä URLin muodostamisessa (ks. ylempää JSON_URL) ja hae Volleylla sen avulla
        // pelkästään kyseisen id:n takana oleva kommenttidata (yksittäinen JSON-objekti)
        // huomaa tässä tapauksessa että GSON -muunnoksessa pitää käyttää yhden objektin esimerkkiä
        // var item : Comment = gson.fromJson(response, Comment::class.java)

        // hyvät puolet: aina ajantasainen data
        // huono puoli: enemmän koodia

        // 2. laita fragmenttien välille lisää parametreja (esim. kommentin id, name, email, body jne)
        // ja aseta nämä argumentit suoraan omiin TextVieweihin ApiDetailFragmentin koodissa

        // hyvät puolet: yksinkertainen koodi, huomattavasti vähemmän tietoliikennettä
        // huono puoli: data voi olla vanhentunut

        // 3. muuta koko comment-olio aiemmassa fragmentissa JSON-formaattiin, ja siirrä vain
        // JSON-muuttuja tähän fragmenttiin

        // hyvät ja huonot puolet samat kuin vaihtoehdossa 2, mutta lisäksi vaatii GSON-muunnoksen
        // molemmissa fragmenteissa
        // ApiFragment -> comment-olio -> JSON ..... ja myöhemmin ApiDetailFragment: JSON -> comment-olio

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
